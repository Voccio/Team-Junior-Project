using UnityEngine;
using System.Collections;

public class HuD : MonoBehaviour 
{
	static int iLives;

	void OnGUI(){
		GUI.Box (new Rect (0,0,100,25), "Lives: "+iLives);
		GUI.Box (new Rect (0,Screen.height - 50,100,25), "Level: "+Application.loadedLevel);
		GUI.Box (new Rect (Screen.width - 100,Screen.height - 50,100,25), ""+Time.timeSinceLevelLoad);
	}

}