using UnityEngine;
using System.Collections;

public class GuiText : MonoBehaviour 
{
void OnGUI () {
		// Make a background box
		GUI.Box(new Rect(0,0,1024,764), "Area of Gray");

		// Make the first button. If it is pressed, Application.Loadlevel (1) will be executed
		if(GUI.Button(new Rect(500,80,80,20), "Play Game")) {
			Application.LoadLevel(1);
		}

		// Make the second button.
		if(GUI.Button(new Rect(500,140,80,20), "Options")) {
			Application.LoadLevel(2);
		}
		
		if(GUI.Button(new Rect(500,200,80,20), "Quit Game")) {
			Application.LoadLevel(3);
		}
	}
	
}
