var bExit : boolean;
function OnMouseOver()
{	
	bExit = true;
}
function OnMouseExit()
{
	bExit = false;
}
function Update()
{
	if(Input.GetMouseButtonDown (0) && bExit)
	{	
		Application.Quit();
	}
}